This code is licensed under the GNU General Public License, version 3.
See <http://www.gnu.org/licenses/gpl.html>
