import numpy as np

rng = np.random.default_rng()

CDl = rng.uniform(1.5,1.9)

print(CDl)
