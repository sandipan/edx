import numpy as np

with open('dTdata.npy','rb') as f:
    dT = np.load(f)


